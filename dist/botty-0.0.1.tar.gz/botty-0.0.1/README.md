# talk.py
A python3 chatbot, linking a number of services together so code can be written quicker and more efficiently

![Docs on github pages](https://img.shields.io/badge/Docs-on%20github%20pages-brightgreen)
