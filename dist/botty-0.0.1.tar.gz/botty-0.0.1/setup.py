from setuptools import setup

setup(
    name='botty',
    version='0.0.1',
    description='',
    long_description='',
    url='https://clicksminuteper.net',
    author='Minion3665',
    author_email='nathan@clicksminuteper.net',
    packages=[],
    classifiers=['Development Status :: 1 - Planning'],
)
